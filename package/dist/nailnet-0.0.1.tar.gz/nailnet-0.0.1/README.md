# NAIL Net

This is a Nueral Artificial Intelligence Library Network for python.
